# My crawler for tianchi competition

## usage:
pip install tianchi-crawler

